package com.stock.rest;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.stock.service.StockAccountService;
import com.stock.domain.StockAccount;

//TODO Declare the class is a REST Controller
//TODO Map the entire class to the /accounts URI
@RestController
@RequestMapping("/accounts")
public class StockAccountResource {

	//TODO Inject the stock account service
	@Autowired
	StockAccountService stockAccountService;
	
	
	
	//TODO Create a method to retrieve all the stock accounts
	@RequestMapping("/")
	public Collection<StockAccount> getAllItem() {
		Collection<StockAccount> results = stockAccountService.findAll();
		return results;
	}
	//TODO Create a method to retrieve a stock account by id
	@RequestMapping("/{id}")
	public StockAccount findStockAccount(@PathVariable("id")Long id) {
		return stockAccountService.findById(id);
	}
	//TODO Create a method to retrieve a stock account by name
	// May need to fix this!!!
	@RequestMapping("/{name}")
	public Collection<StockAccount> findStockAccount(@PathVariable("name")String name) {
		return stockAccountService.findByName(name);
	}

}
